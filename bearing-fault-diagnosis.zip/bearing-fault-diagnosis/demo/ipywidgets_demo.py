"""
Bearing Fault Diagnosis — inline Jupyter/Kaggle demo (ipywidgets).

Not a standalone script: paste this into a notebook cell (or %run it)
after the export cell that defines DEPLOY_MODEL_BYTES and metadata.
Kept here as a versioned copy of notebooks/bearing_fault_diagnosis.ipynb's
last cell, so the demo logic can be reviewed/diffed outside the notebook.
"""

import ipywidgets as widgets
from IPython.display import display, clear_output
import matplotlib.pyplot as plt
import numpy as np
import scipy.io as sio
import tensorflow as tf

# --- Load the exported TFLite model from memory ---
_interpreter = tf.lite.Interpreter(model_content=DEPLOY_MODEL_BYTES)
_interpreter.allocate_tensors()
_in_details = _interpreter.get_input_details()[0]
_out_details = _interpreter.get_output_details()[0]

CLASS_LABELS = metadata["class_labels"]
DEMO_WINDOW_SIZE = metadata["window_size"]
IN_SCALE = metadata["input_quantization"]["scale"]
IN_ZP = metadata["input_quantization"]["zero_point"]
OUT_SCALE = metadata["output_quantization"]["scale"]
OUT_ZP = metadata["output_quantization"]["zero_point"]


def standardize_window(window):
    mu = window.mean()
    sigma = window.std() + 1e-8
    return (window - mu) / sigma


def extract_de_signal(mat_path):
    data = sio.loadmat(mat_path)
    de_key = next((k for k in data.keys() if k.endswith("DE_time")), None)
    if de_key is None:
        raise ValueError("No '*_DE_time' channel found in this .mat file.")
    return np.asarray(data[de_key]).squeeze().astype(np.float32)


def generate_synthetic_signal(fault_type, severity, noise_level, n_samples=8192, seed=0):
    """Illustrative-only synthetic vibration signal — NOT real bearing data."""
    rng = np.random.default_rng(seed)
    t = np.arange(n_samples) / 12000.0
    shaft_freq = 30.0
    signal = 0.3 * np.sin(2 * np.pi * shaft_freq * t)
    if fault_type != "Normal":
        fault_freq_map = {"Ball": 4.7, "InnerRace": 5.4, "OuterRace": 3.6}
        impact_rate = fault_freq_map.get(fault_type, 4.0) * shaft_freq
        for it in np.arange(0, t[-1], 1.0 / impact_rate):
            idx = int(it * 12000)
            if idx < n_samples:
                decay = np.exp(-np.arange(n_samples - idx) * 0.01)
                carrier = np.sin(2 * np.pi * 2000 * (np.arange(n_samples - idx) / 12000.0))
                signal[idx:] += severity * decay * carrier
    signal += noise_level * rng.standard_normal(n_samples)
    return signal.astype(np.float32)


def run_inference(window):
    std_window = standardize_window(window)
    x_int8 = np.round(std_window / IN_SCALE + IN_ZP).clip(-128, 127).astype(np.int8)
    x_int8 = x_int8.reshape(1, DEMO_WINDOW_SIZE, 1)
    _interpreter.set_tensor(_in_details["index"], x_int8)
    _interpreter.invoke()
    out_int8 = _interpreter.get_tensor(_out_details["index"])[0]
    probs = (out_int8.astype(np.float32) - OUT_ZP) * OUT_SCALE
    probs = np.clip(probs, 0, 1)
    probs = probs / probs.sum() if probs.sum() > 0 else probs
    label_probs = {CLASS_LABELS[i]: float(probs[i]) for i in range(len(CLASS_LABELS))}
    pred_label = CLASS_LABELS[int(np.argmax(probs))]
    return pred_label, label_probs, std_window


def plot_and_report(window, title):
    pred_label, probs, std_window = run_inference(window)

    fig, axes = plt.subplots(1, 3, figsize=(14, 3.2))
    axes[0].plot(std_window, linewidth=0.6)
    axes[0].set_title(f"Signal — {title}")

    freqs = np.fft.rfftfreq(len(std_window), d=1.0)
    mag = np.abs(np.fft.rfft(std_window))
    axes[1].plot(freqs, mag, linewidth=0.6, color="darkorange")
    axes[1].set_title("Spectrum")

    axes[2].barh(list(probs.keys()), list(probs.values()), color="steelblue")
    axes[2].set_xlim(0, 1)
    axes[2].set_title(f"Prediction: {pred_label}")

    plt.tight_layout()
    plt.show()
    print(f"Predicted class: {pred_label}")
    for k, v in probs.items():
        print(f"  {k:12s} {v:.3f}")


# ---------------- Widgets: synthetic signal ----------------
fault_dd = widgets.Dropdown(options=CLASS_LABELS, description="Fault:")
severity_sl = widgets.FloatSlider(value=1.0, min=0.0, max=3.0, step=0.1, description="Severity:")
noise_sl = widgets.FloatSlider(value=0.15, min=0.0, max=1.0, step=0.05, description="Noise:")
seed_sl = widgets.IntSlider(value=0, min=0, max=100, description="Seed:")
run_btn = widgets.Button(description="Generate & classify", button_style="primary")
out = widgets.Output()


def on_run_clicked(b):
    with out:
        clear_output(wait=True)
        signal = generate_synthetic_signal(fault_dd.value, severity_sl.value, noise_sl.value, seed=seed_sl.value)
        plot_and_report(signal[:DEMO_WINDOW_SIZE], f"synthetic '{fault_dd.value}'")


run_btn.on_click(on_run_clicked)

display(widgets.HTML("<h3>Bearing Fault Diagnosis — Synthetic Signal Demo</h3>"))
display(widgets.VBox([fault_dd, severity_sl, noise_sl, seed_sl, run_btn, out]))

# ---------------- Widgets: upload real .mat file ----------------
upload = widgets.FileUpload(accept=".mat", multiple=False, description="Upload .mat")
start_sl = widgets.FloatSlider(value=0, min=0, max=100, description="Window %:")
run_btn2 = widgets.Button(description="Classify window", button_style="primary")
out2 = widgets.Output()


def on_run2_clicked(b):
    with out2:
        clear_output(wait=True)
        if not upload.value:
            print("Upload a .mat file first.")
            return
        uploaded_file = list(upload.value.values())[0] if isinstance(upload.value, dict) else upload.value[0]
        content = uploaded_file["content"] if isinstance(uploaded_file, dict) else uploaded_file.content
        tmp_path = "/kaggle/working/_tmp_upload.mat"
        with open(tmp_path, "wb") as f:
            f.write(content)
        signal = extract_de_signal(tmp_path)
        if len(signal) < DEMO_WINDOW_SIZE:
            print(f"Signal too short ({len(signal)} samples).")
            return
        max_start = len(signal) - DEMO_WINDOW_SIZE
        start = int(start_sl.value / 100 * max_start)
        plot_and_report(signal[start:start + DEMO_WINDOW_SIZE], f"upload @ sample {start}")


run_btn2.on_click(on_run2_clicked)

display(widgets.HTML("<h3>Classify a real CWRU .mat file</h3>"))
display(widgets.VBox([upload, start_sl, run_btn2, out2]))
